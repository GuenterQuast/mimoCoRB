# setup.py for compatibility with old setuptools
from setuptools import setup
setup() # reads from pyproject.toml
